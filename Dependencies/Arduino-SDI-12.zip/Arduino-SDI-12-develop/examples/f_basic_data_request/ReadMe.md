# Example F: Basic data request to a single sensor

This is a simple demonstration of the SDI-12 library for Arduino.

This is a very basic (stripped down) example where the user initiates a measurement and receives the results to a terminal window without typing numerous commands into the terminal.
